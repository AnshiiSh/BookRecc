from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('Gatsby.html')

@app.route('/author')
def author():
    return render_template('Fiction-1.html')

if __name__ == '__main__':
    app.run(debug=True)
