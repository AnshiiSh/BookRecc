document.getElementById("send-btn").addEventListener("click", function() {
    sendMessage();
});

document.getElementById("user-input").addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        sendMessage();
    }
});

function sendMessage() {
    const userInput = document.getElementById("user-input").value;
    if (userInput.trim() === "") return;

    addChatMessage("You", userInput);
    document.getElementById("user-input").value = "";  // Clear input field

    // Simulate sending the message to the server (you would replace this with actual server interaction)
    setTimeout(function() {
        simulateResponse(userInput);
    }, 500);
}

function addChatMessage(sender, message) {
    const chatLog = document.getElementById("chat-log");
    const messageElement = document.createElement("div");
    messageElement.innerHTML = `<strong>${sender}:</strong> ${message}`;
    chatLog.appendChild(messageElement);
    chatLog.scrollTop = chatLog.scrollHeight;  // Scroll to the bottom
}

function simulateResponse(userMessage) {
    // Normalize the user input to lowercase
    userMessage = userMessage.trim().toLowerCase();

    // Define responses
    const responses = {
        "hello": "Hello! How can I assist you with book recommendations?",
        "recommend": "Sure! Can you tell me what genre you're interested in?",
        "romance": "I recommend 'Pride and Prejudice' by Jane Austen.",
        "science fiction": "You might enjoy 'Dune' by Frank Herbert.",
        "darkromance": "You might enjoy 'Legacies of God' by Rina Kent.",
        "help": "I can help you with book recommendations, or you can ask me a question.",
        "biography": "You might like 'The Diary of a Young Girl' by Anne Frank.",
        "fiction": "I would recommend 'The Great Gatsby' by F. Scott Fitzgerald or 'The Catcher in the Rye' by J.D. Salinger.",
        "bye": "Thanks for chatting with me! Have a great day!",
        "thank you": "You're welcome! Let me know if you need any more help with book recommendations.",
        "rude": "Oh, my apologies! I didn't mean to offend you. Let's start fresh!",
        "thanks": "My pleasure! Let me know if you need any more help with book recommendations.",
    };

    // Default response
    let botResponse = "I'm not sure how to respond to that. Could you clarify?";

    // Check if userMessage matches any keyword exactly
    if (responses[userMessage]) {
        botResponse = responses[userMessage];
    } else {
        // Check for keywords in the user's message
        for (let keyword in responses) {
            if (userMessage.includes(keyword)) {
                botResponse = responses[keyword];
                break;
            }
        }
    }

    // Add the bot response to the chat log
    addChatMessage("PageTurner", botResponse);
}
