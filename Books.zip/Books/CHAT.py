import random

# Sample book recommendations for different genres
books = {
    "science fiction": [
        "Dune by Frank Herbert",
        "The Left Hand of Darkness by Ursula K. Le Guin",
        "Neuromancer by William Gibson"
    ],
    "fantasy": [
        "The Hobbit by J.R.R. Tolkien",
        "Harry Potter by J.K. Rowling",
        "A Game of Thrones by George R.R. Martin"
    ],
    "romance": [
        "Pride and Prejudice by Jane Austen",
        "Me Before You by Jojo Moyes",
        "The Notebook by Nicholas Sparks"
    ],
    "mystery": [
        "Gone Girl by Gillian Flynn",
        "The Girl with the Dragon Tattoo by Stieg Larsson",
        "Sherlock Holmes by Arthur Conan Doyle"
    ],
    "horror": [
        "The Shining by Stephen King",
        "Dracula by Bram Stoker",
        "Frankenstein by Mary Shelley"
    ]
}

# Function to get book recommendation based on user input
def get_book_recommendation(genre):
    genre = genre.lower()
    if genre in books:
        return random.choice(books[genre])
    else:
        return "Sorry, I don't have any recommendations for that genre."

# PageTurner chatbot
def pageturner_chatbot():
    print("Welcome to PageTurner! I can recommend books for you.")
    print("Ask me for book recommendations by genre (e.g., 'science fiction', 'fantasy', etc.)")
    
    while True:
        user_input = input("You: ").lower()

        # Check if the user is asking for a recommendation
        if "recommend" in user_input or "suggest" in user_input:
            for genre in books.keys():
                if genre in user_input:
                    print(f"PageTurner: I recommend '{get_book_recommendation(genre)}'.")
                    break
            else:
                print("PageTurner: I'm not sure about that genre. Try asking about 'science fiction', 'fantasy', 'romance', 'mystery', or 'horror'.")

        # Handle exit case
        elif "exit" in user_input or "bye" in user_input:
            print("PageTurner: Goodbye! Happy reading!")
            break

        # Default response for unrecognized inputs
        else:
            print("PageTurner: I can help you with book recommendations. Just ask me!")

# Run the chatbot
pageturner_chatbot()
