// JavaScript code for the search bar autocomplete
const searchInput = document.getElementById('search-input');
const searchResults = document.getElementById('search-results');

searchInput.addEventListener('input', async (e) => {
  const searchTerm = e.target.value.trim();
  const results = await fetch(`https://api.example.com/search?q=${searchTerm}`);
  const books = await results.json();

  searchResults.innerHTML = '';
  books.forEach((book) => {
    const listItem = document.createElement('li');
    listItem.textContent = book.title;
    searchResults.appendChild(listItem);
  });
});

// JavaScript code for the book recommendations
const bookGrid = document.getElementById("list");

fetch('https://api.example.com/recommendations')
  .then(response => response.json())
  .then(books => {
    books.forEach((book) => {
      const bookElement = document.createElement('div');
      bookElement.className = 'book';
      bookElement.innerHTML = `
        <img src="${book.coverUrl}" alt="Book Cover">
        <h2 class="title">${book.title}</h2>
        <p class="author">${book.author}</p>
      `;
      bookGrid.appendChild(bookElement);
    });
  });