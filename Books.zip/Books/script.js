// Maintain a history of book recommendations and their states
const recommendationHistory = [];

// Add event listeners to book elements
const bookElements = document.querySelectorAll(".book");

bookElements.forEach((bookElement) => {
  bookElement.addEventListener("mouseover", () => {
    bookElement.style.transform = "scale(1.1)";
    bookElement.style.boxShadow = "0 0 10px rgba(0, 0, 0, 0.5)";
  });

  bookElement.addEventListener("mouseout", () => {
    bookElement.style.transform = "scale(1)";
    bookElement.style.boxShadow = "none";
  });
});

// Add a container for the book recommendations
const recommendationSection = document.querySelector(".recommendation-section");

// Simulate loading more books (you can replace this with an API call or database query)
const books = [
  {
    title: "The Nightingale",
    author: "Kristin Hannah",
    cover: "book-cover1.jpeg"
  },
  {
    title: "The Hate U Give",
    author: "Angie Thomas",
    cover: "book-cover2.jpeg"
  },
  {
    title: "To Kill a Mockingbird",
    author: "Harper Lee",
    cover: "book-cover3.jpeg"
  },
  {
    title: "The Great Gatsby",
    author: "F. Scott Fitzgerald",
    cover: "book-cover4.jpeg"
  },
  {
    title: "Pride and Prejudice",
    author: "Jane Austen",
    cover: "book-cover5.jpeg"
  },
  {
    title: "The Handmaid's Tale",
    author: "Margaret Atwood",
    cover: "book-cover6.jpeg"
  },
  {
    title: "1984",
    author: "George Orwell",
    cover: "book-cover7.jpeg"
  },
  {
    title: "Wuthering Heights",
    author: "Emily Bronte",
    cover: "book-cover8.jpeg"
  }
];

// Function to display a book
function displayBook(book) {
  const bookHTML = `
    <div class="book">
      <img src="${book.cover}" alt="Book Cover">
      <h2 class="title">${book.title}</h2>
      <p class="author">${book.author}</p>
    </div>
  `;
  recommendationSection.innerHTML = bookHTML;
}

// Function to auto-scroll books
function autoScrollBooks() {
  let currentIndex = 0;
  const intervalId = setInterval(() => {
    if (currentIndex >= books.length) {
      currentIndex = 0;
    }
    displayBook(books[currentIndex]);
    currentIndex++;
  }, 3000); // Change the book every 3 seconds
}

// Start auto-scrolling books
autoScrollBooks();